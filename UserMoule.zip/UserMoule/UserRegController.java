package com.wcd.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.wcd.exception.CustomException;
import com.wcd.service.IUserReg;
import model.UserRegistration;

@Controller
public class UserRegController {
	@Autowired
	private IUserReg iUserRegSer;
	
	public void setiUserRegSer(IUserReg iUserRegSer) {
		this.iUserRegSer = iUserRegSer;
	}
	@RequestMapping(value = "/userRegModel", method = RequestMethod.GET)
	public String listUserReg(Model model) {
		
		model.addAttribute("userReg", new UserRegistration());// model
		
		return "personalDetailReg";// view name
	}
	@RequestMapping(value = "/userRegdetail/add", method = RequestMethod.POST)
public String addUserReg(
		
		@ModelAttribute("userReg")
		@Valid UserRegistration n,
		BindingResult result,
		Model model) {
		System.out.println("hiii1");

			
				this.iUserRegSer.addUserReg(n);
				System.out.println("added record ..");
			
			return "redirect:/userRegModel";


	}
@RequestMapping("/listUserReq")    
public String viewUserReq(Model m){    
	m.addAttribute("userReqdetail", new UserRegistration());
    m.addAttribute("userReqDetailList",this.iUserRegSer.listUserRegDetail());  
    return "adminTrainee";    
}    
@RequestMapping("/removeUserReq/{userReg.userRegId}")
public String removeCourseDet1(
		@PathVariable("userReg.userRegId") int id) throws CustomException {
	if (id > 0) {
		this.iUserRegSer.removeUserReg(id);
	} else {
	
		throw new CustomException("Given Id Not Found","404");
	}
	return "redirect:/listUserReq";
}

@RequestMapping("/editUserReq/{userReg.userRegId}")
public String showEditTraineePage(
		@PathVariable("userReg.userRegId") int id, Model model) {
	UserRegistration userReqDetObj = 
			this.iUserRegSer.getUserRegById(id);
	model.addAttribute("userReqdetail", userReqDetObj);
	List<UserRegistration> userReqDetListObj =
			this.iUserRegSer.listUserRegDetail();
	model.addAttribute("userReqDetailList", userReqDetListObj);
	return "adminTrainee";// view name
}
@RequestMapping(value="/saveUserReq",method = RequestMethod.POST)    
public String SaveUserReq(
		@ModelAttribute("userReqdetail") UserRegistration n){    
	System.out.println("hii");
	this.iUserRegSer.updateUserReg(n); 
    return "redirect:/listUserReq";    
}    
@RequestMapping("/acceptUserReq/{userReg.userRegId}")
//@ExceptionHandler({ CustomException.class })
public String acceptUserRegDet(
		@PathVariable("userReg.userRegId") 
		int id) throws CustomException {
	if (id > 0) {
		this.iUserRegSer.acceptUserReg(id);
		
	} else {
		throw new CustomException("Given Id Not Found","404");
	}
	return "redirect:/listUserReq";
}

}
