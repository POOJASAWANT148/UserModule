package model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
@Component
@Entity
public class FamilyDetails implements Serializable {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int familyId;
private String fatherName;
private String motherName;
private String fatherAddress;
private String maritalStatus;
private int familyPhoneNumber;
private int noOfDepandence;
public int getFamilyId() {
	return familyId;
}
public void setFamilyId(int familyId) {
	this.familyId = familyId;
}
public String getFatherName() {
	return fatherName;
}
public void setFatherName(String fatherName) {
	this.fatherName = fatherName;
}
public String getMotherName() {
	return motherName;
}
public void setMotherName(String motherName) {
	this.motherName = motherName;
}
public String getFatherAddress() {
	return fatherAddress;
}
public void setFatherAddress(String fatherAddress) {
	this.fatherAddress = fatherAddress;
}
public String getMaritalStatus() {
	return maritalStatus;
}
public void setMaritalStatus(String maritalStatus) {
	this.maritalStatus = maritalStatus;
}
public int getFamilyPhoneNumber() {
	return familyPhoneNumber;
}
public void setFamilyPhoneNumber(int familyPhoneNumber) {
	this.familyPhoneNumber = familyPhoneNumber;
}
public int getNoOfDepandence() {
	return noOfDepandence;
}
public void setNoOfDepandence(int noOfDepandence) {
	this.noOfDepandence = noOfDepandence;
}
@Override
public String toString() {
	return "FamilyDetails [familyId=" + familyId + ", fatherName=" + fatherName + ", motherName=" + motherName
			+ ", fatherAddress=" + fatherAddress + ", maritalStatus=" + maritalStatus + ", familyPhoneNumber="
			+ familyPhoneNumber + ", noOfDepandence=" + noOfDepandence + "]";
}
public FamilyDetails(int familyId, String fatherName, String motherName, String fatherAddress, String maritalStatus,
		int familyPhoneNumber, int noOfDepandence) {
	super();
	this.familyId = familyId;
	this.fatherName = fatherName;
	this.motherName = motherName;
	this.fatherAddress = fatherAddress;
	this.maritalStatus = maritalStatus;
	this.familyPhoneNumber = familyPhoneNumber;
	this.noOfDepandence = noOfDepandence;
}
public FamilyDetails() {
	super();
}


}
