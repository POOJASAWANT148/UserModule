package com.wcd.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.wcd.dao.IUserRegDao;
import com.wcd.dao.UserRegDaoImpl;

import model.Course;
import model.User;
import model.UserRegistration;
@Service
public class UserRegService implements IUserReg{
private IUserRegDao userDao;
@Autowired
public void setUserDao(IUserRegDao userDao) {
	this.userDao = userDao;
}
	@Override
	@Transactional
	public void addUserReg(UserRegistration userReg) {
		System.out.println("hiii");
this.userDao.addUserReg(userReg);
		
	}
	

	@Override
	@Transactional
	public void updateUserReg(UserRegistration userReg) {
		this.userDao.updateUserReg(userReg);;
		
	}
	@Override
	@Transactional
	public List<UserRegistration> listUserRegDetail() {

		return this.userDao.listUserReg();
	}
	@Override
	public UserRegistration getUserRegById(int id) {
	
		return this.userDao.getUserRegById(id);
	}
	@Override
	@Transactional
	public void removeUserReg(int id) {
this.userDao.removeUserReg(id);
		
	}
	@Override
	public void acceptUserReg(int id) {
		this.userDao.acceptUserReg(id);
		
	}
	@Override
	public boolean showStatusUserReg(int id) {
		
		return this.userDao.showStatusUserReg(id);
	}


}
