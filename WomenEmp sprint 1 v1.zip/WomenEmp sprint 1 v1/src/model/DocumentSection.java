package model;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Lob;

public class DocumentSection {
@Column(name="addhaar")
@Lob
private Blob addhaarcard;
@Column(name="pan")
@Lob
private Blob pancard;
public Blob getAddhaarcard() {
	return addhaarcard;
}
public DocumentSection() {
	super();
}
public DocumentSection(Blob addhaarcard, Blob pancard) {
	super();
	this.addhaarcard = addhaarcard;
	this.pancard = pancard;
}
@Override
public String toString() {
	return "DocumentSection [addhaarcard=" + addhaarcard + ", pancard=" + pancard + "]";
}
public void setAddhaarcard(Blob addhaarcard) {
	this.addhaarcard = addhaarcard;
}
public Blob getPancard() {
	return pancard;
}
public void setPancard(Blob pancard) {
	this.pancard = pancard;
}
}
