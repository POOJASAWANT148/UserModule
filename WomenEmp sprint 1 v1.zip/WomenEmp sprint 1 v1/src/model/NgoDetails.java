package model;

import java.sql.Blob;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="NgoDetails")
public class NgoDetails {
	@Id
	@Column(name="detailId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer detailId;
	@Column
	private String address;
	@Column
	private String achievements;
	/*@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="ngoId")
	@MapsId
	private Ngo ngo;
	public Ngo getNgo() {
		return ngo;
	}

	public void setNgo(Ngo ngo) {
		this.ngo = ngo;
	}*/
	@Column
	private Date dateOfReg;
	@Column
	private String projectInCharge;
	@Column
	private String position;
	@Column
	private String email;
	@Column
	private String MobileNo;
	//private Blob regCerti;
	@Column
	private int noOfStaff;
	/*
	 @OneToMany(cascade=CascadeType.ALL,mappedBy="ngoList" )
	 private List<Course> courseList;
	 */
	@Column
	private String status;

	
	/*  public List<Course> getCourseList() { return courseList; } 
	  
	  public void setCourseList(List<Course> courseList) { this.courseList = courseList; }
	 */
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getDetailId() {
		return detailId;
	}
	public void setDetailId(Integer detailId) {
		this.detailId = detailId;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	public String getAchievements() {
		return achievements;
	}
	public void setAchievements(String achievements) {
		this.achievements = achievements;
	}
	
	public Date getDateOfReg() {
		return dateOfReg;
	}
	public void setDateOfReg(Date dateOfReg) {
		this.dateOfReg = dateOfReg;
	}
	public String getProjectInCharge() {
		return projectInCharge;
	}
	public void setProjectInCharge(String projectInCharge) {
		this.projectInCharge = projectInCharge;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}

	/*
	 * public Blob getRegCerti() { return regCerti; } public void setRegCerti(Blob
	 * regCerti) { this.regCerti = regCerti; }
	 */
	public int getNoOfStaff() {
		return noOfStaff;
	}
	public void setNoOfStaff(int noOfStaff) {
		this.noOfStaff = noOfStaff;
	}
	public NgoDetails(Integer detailId, String orgName, String address, String scheme, String achievements, String uuid,
			Date dateOfReg, String projectInCharge, String position, String email, String mobileNo, /* Blob regCerti, */
			int noOfStaff,List<Course> courseList, String status) {
		super();
		this.detailId = detailId;

		this.address = address;
	
		this.achievements = achievements;
		
		this.dateOfReg = dateOfReg;
		this.projectInCharge = projectInCharge;
		this.position = position;
		this.email = email;
		MobileNo = mobileNo;
		//this.regCerti = regCerti;
		this.noOfStaff = noOfStaff;
	//	this.courseList = courseList;
		this.status = status;
	}
	public NgoDetails() {
		super();
	}
	@Override
	public String toString() {
		return "NgoDetails [detailId=" + detailId + ", address=" + address + ", achievements=" + achievements +  ", dateOfReg=" + dateOfReg
				+ ", projectInCharge=" + projectInCharge + ", position=" + position + ", email=" + email + ", MobileNo="
				+ MobileNo + ", noOfStaff=" + noOfStaff + ",  status=" + status + "]";
	}
	
	//", regCerti=" + regCerti + , courseList=" + courseList+"
	
	
}
