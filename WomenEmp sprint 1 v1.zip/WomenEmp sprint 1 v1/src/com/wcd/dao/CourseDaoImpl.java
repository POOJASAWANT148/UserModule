package com.wcd.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.Course;
import model.NgoDetails;
@Repository
public class CourseDaoImpl implements ICourseDao {
	private static final Logger logger = 			
			LoggerFactory.getLogger(CourseDaoImpl.class);
private SessionFactory sessionFactory;
private Transaction tx;
	@Autowired
	public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
	}
	
	
	@Override
	@Transactional
	public void addCourseDet(Course n) {
		
		Session session = this.sessionFactory.openSession();
		 tx = session.beginTransaction();
		 System.out.println("hiiiiii");
		session.persist(n);
		logger.info("Course saved successfully, Course Details="+ n);
		tx.commit();
		session.close();
		
	}

	@Override
	public void updateCourseDet(Course p) {
		Session session = 
				this.sessionFactory
				.openSession();
		tx=session.beginTransaction();
		session.update(p);
		logger.info("Course updated successfully, "
				+ "Course Details=" + p);
		tx.commit();
		session.close();
		
	}

	@Override
	public List<Course> listCourseDetail() {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		List<Course> courseDetList = session.createQuery("from Course").list();
		for (Course p : courseDetList) {
			logger.info("Course List::" + p);
		}
		tx.commit();
		session.close();
		return courseDetList;
	}

	@Override
	public Course getCourseById(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		Course p = (Course) session.load(Course.class, new Integer(id));
		logger.info("Course loaded successfully, Course details=" + p);
		tx.commit();
		session.close();
		return p;
	}

	@Override
	public void removeCourse(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		Course p = 
		(Course) session.load(Course.class, new Integer(id));
		if (null != p) {
			session.delete(p);
		}else {
			logger.error
			("Course NOT deleted, with Course Id=" +id);
		}
		logger.info("Course deleted successfully, Course details=" + p);
		tx.commit();
		session.close();
	}

}
