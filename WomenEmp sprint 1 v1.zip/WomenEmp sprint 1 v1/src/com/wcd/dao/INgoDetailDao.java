package com.wcd.dao;



import java.util.List;

import org.springframework.stereotype.Repository;

import model.Ngo;
import model.NgoDetails;
@Repository
public interface INgoDetailDao {
	public void addNgoDet(NgoDetails n);//insert
	public void updateNgoDet(NgoDetails p);//update/modify
	public List<NgoDetails> listNgoDetail();//retrieve/listAll
	public NgoDetails getNgoDetById(int id);//search
	public void removeNgoDet(int id);//delete/remove
	public void acceptNgoDet(int id);
	public boolean showStatusNgo(int id);
}
