package com.wcd.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import model.Course;
@Repository
public interface ICourseDao {
	public void addCourseDet(Course n);//insert
	public void updateCourseDet(Course p);//update/modify
	public List<Course> listCourseDetail();//retrieve/listAll
	public Course getCourseById(int id);//search
	public void removeCourse(int id);//delete/remove
}
