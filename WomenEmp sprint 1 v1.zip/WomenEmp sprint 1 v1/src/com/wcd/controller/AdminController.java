package com.wcd.controller;

public class AdminController {

}
