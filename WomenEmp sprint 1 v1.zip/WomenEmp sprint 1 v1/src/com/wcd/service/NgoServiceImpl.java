package com.wcd.service;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wcd.dao.INgoDao;

import model.Ngo;
@Service
public class NgoServiceImpl implements INgoService{
	private INgoDao ngoDao;
	@Autowired
		public void setNgoDao(INgoDao ngoDao) {
	    this.ngoDao = ngoDao;
	}
		
	@Override
	@Transactional
	public void addNgo(Ngo n) {
	this.ngoDao.addNgo(n);
		
	}

	
	@Override
	@Transactional
	public Ngo getNgoDetails(int ngoDetailsId) {
	return this.ngoDao.getNgoDetails(ngoDetailsId);
		
	}

	@Override
	@Transactional
	public boolean verifyUser(String uuid, String password) {
		System.out.println("service");
		return this.ngoDao.verifyUser(uuid, password);
	}

}
