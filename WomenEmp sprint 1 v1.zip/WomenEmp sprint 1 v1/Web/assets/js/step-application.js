                // for pdf file uploaad
                var executiveMembers = {};
                var bankDetails = {};
                var trainerDetails = {};
                var landAndBuildingDetails = {};
                var equipmentDetails = {};
                var beneficiaryDetails = {};
                var financialDetails = {};
                var grantDetails = {};
                var trainersDetails = {};

                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.byeLawApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#byeLawPdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");

                                            /*is document exist action start*/

                                            $("#bylawfileId").show();
                                            $("#bylawfileId").attr("href", jsresp.file_path);


                                            /*is document exist action end*/


                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 3,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#byeLawApplicationPdfUpload').dropzone({url: baseURL + "ngo/byeLawUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }
                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.legalEntityApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#legalEntityPdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            /*is document exist action start*/

                                            $("#legal_entity_link").show();
                                            $("#legal_entity_link").attr("href", jsresp.file_path);


                                            /*is document exist action end*/
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 60,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#legalEntityApplicationPdfUpload').dropzone({url: baseURL + "ngo/legalEntityUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }
                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.nsdcApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#nsdcPdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            /*is document exist action start*/
                                            $("#nsdc_link").show();
                                            $("#nsdc_link").attr("href", jsresp.file_path);
                                            /*is document exist action end*/


                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 3,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#nsdcApplicationPdfUpload').dropzone({url: baseURL + "ngo/nsdcUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }
                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.perEvaluatedApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#perEvaluatedPdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");

                                            /*is document exist action start*/
                                            $("#pre_evaluated_link").show();
                                            $("#pre_evaluated_link").attr("href", jsresp.file_path);
                                            /*is document exist action start*/

                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 3,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#perEvaluatedApplicationPdfUpload').dropzone({url: baseURL + "ngo/perEvaluatedUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }

                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.proCostuploadFile = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#proCostFile').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            $("#pro_costfileId").show();
                                            $("#pro_costfileId").attr("href", jsresp.file_path);
                                            /* location.href = location.href; */
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 60,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#proCostuploadFile').dropzone({url: baseURL + "ngo/proCostUploadFilePdf", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }





                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.docOneApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#docOnePdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            /*$('#doc_path_link').attr("href", jsresp.file_path);
                                             location.href = location.href; */
                                            /*is document exist action start*/
                                            $.ajax({
                                                type: "get",
                                                url: baseURL + 'ngo/isdocumentExistsc',
                                                data: {"appId": getParameterByName("aid"), "docId": '1'},
                                                dataType: 'text',
                                                success: function (data) {
                                                    //alert(data);
                                                    if (data == "true")
                                                    {
                                                        $("#doc_path_fileId").show();
                                                        $("#doc_path_fileId").attr("href", jsresp.file_path);

                                                    }

                                                }

                                            });
                                            /*is document exist action end*/
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 3,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#docOneApplicationPdfUpload').dropzone({url: baseURL + "ngo/docOneUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }
                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.docTwoApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#docTwoPdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            $('#doc_path_link').attr("href", jsresp.file_path);
                                            location.href = location.href;
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 60,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#docTwoApplicationPdfUpload').dropzone({url: baseURL + "ngo/docTwoUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }
                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.docThreeApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#docThreePdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            $('#doc_path_link').attr("href", jsresp.file_path);
                                            location.href = location.href;
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 60,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#docThreeApplicationPdfUpload').dropzone({url: baseURL + "ngo/docThreeUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }
                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.docFourApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#docFourPdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            $('#doc_path_link').attr("href", jsresp.file_path);
                                            location.href = location.href;
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 60,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#docFourApplicationPdfUpload').dropzone({url: baseURL + "ngo/docFourUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }
                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.docFiveApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#docFivePdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            $('#doc_path_link').attr("href", jsresp.file_path);
                                            location.href = location.href;
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 60,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#docFiveApplicationPdfUpload').dropzone({url: baseURL + "ngo/docFiveUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }
                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.docSixApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#docSixPdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            $('#doc_path_link').attr("href", jsresp.file_path);
                                            location.href = location.href;
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 60,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#docSixApplicationPdfUpload').dropzone({url: baseURL + "ngo/docSixUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }
                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.docSevenApplicationPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#docSevenPdfUpload').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            $('#doc_path_link').attr("href", jsresp.file_path);
                                            location.href = location.href;
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 60,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#docSevenApplicationPdfUpload').dropzone({url: baseURL + "ngo/docSevenUploadPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }


                if (Controller != "home")
                {
                    Dropzone.autoDiscover = false;
                    Dropzone.options.docadditionalPdfUpload = {
                        success: function (file, response) {
                            var jsresp = JSON.parse(response);
                            var url = window.location.href;
                            var n = url.lastIndexOf("index.html");
                            var pathtoredirect = url.substring(n);

                            if (jsresp.status == true) {
                                swal({
                                    title: "Success",
                                    text: "Document Uploaded Successfully!",
                                    type: "success",
                                    confirmButtonText: "OK",
                                },
                                        function () {
                                            //location.href = baseURL + "ngo"+pathtoredirect;
                                            $('#docadditionalPdf').hide();
                                            $('.modal-backdrop').hide();
                                            $('body').removeClass("modal-open");
                                            /* $('#doc_path_link').attr("href", jsresp.file_path);*/
                                            /* location.href = location.href; */
                                            $("#docadditionaldoc").show();
                                            $("#docadditionaldoc").attr("href", jsresp.file_path);
                                        });
                            } else if (jsresp.status == false)
                            {
                                swal("Error!", "Error In Uploading Try After Some Time.", "error");
                            }
                        },
                        params: {'aid': getParameterByName("aid")},
                        dictDefaultMessage: "Click / Drop here to upload files",
                        addRemoveLinks: true,
                        dictRemoveFile: "Remove",
                        maxFiles: 1,
                        acceptedFiles: ".pdf",
                        maxFilesize: 60,
                        parallelUploads: 35
                    }

                    $(function () {
                        /* Upload Profile Pic */
                        $('#docadditionalPdfUpload').dropzone({url: baseURL + "ngo/docadditionalPdfFile", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
                    });
                }




                jQuery(document).ready(function () {
                    //for Do the bye-laws files show or hide
                    $("#annextureIpartA12").on('change', '#bye_law', function () {
                        var selectedValue = $(this).val();
                        if (selectedValue == "Yes") {
                            $('#annextureIpartA12 #bye_law_file').show();
                        } else {
                            $('#annextureIpartA12 #bye_law_file').hide();
                        }
                    });

                    //for Whether the institution has files show or hide
                    $("#annextureIpartA12").on('change', '#legal_entity', function () {
                        var selectedValue = $(this).val();
                        if (selectedValue == "Yes") {
                            $('#annextureIpartA12 #legal_entity_file').show();
                        } else {
                            $('#annextureIpartA12 #legal_entity_file').hide();
                        }
                    });

                    //for Whether the organisation is registered files show or hide
                    $("#annextureIpartA12").on('change', '#ngo_ps', function () {
                        var selectedValue = $(this).val();
                        if (selectedValue == "Yes") {
                            $('#annextureIpartA12 #ngo_ps_desc').show();
                        } else {
                            $('#annextureIpartA12 #ngo_ps_desc').hide();
                        }
                    });


                    //for  Whether affiliated to National Skill Development Corporation (NSDC) files show or hide
                    $("#annextureIpartA12").on('change', '#nsdc', function () {
                        var selectedValue = $(this).val();
                        if (selectedValue == "Yes") {
                            $('#annextureIpartA12 #nsdc_file').show();
                        } else {
                            $('#annextureIpartA12 #nsdc_file').hide();
                        }
                    });


                    //for Has the performance of the organisation being evaluate files show or hide
                    $("#annextureIpartA12").on('change', '#per_evaluated', function () {
                        var selectedValue = $(this).val();
                        if (selectedValue == "Yes") {
                            $('#annextureIpartA12 #per_evaluated_file').show();
                        } else {
                            $('#annextureIpartA12 #per_evaluated_file').hide();
                        }
                    });

                    //count the textarea
                    var text_max = 1500;
                    $('#count_message').html(text_max + ' remaining');

                    $('#dec_textarea').keyup(function () {
                        var text_length = $('#dec_textarea').val().length;
                        var text_remaining = text_max - text_length;

                        $('#count_message').html(text_remaining + ' remaining');
                    });
					  var remark_max = 250;
                    $('#chars_left_nipccdremarks').html(remark_max + ' remaining');

                    $('#nipccdremarks').keyup(function () {
                        var text_length = $('#nipccdremarks').val().length;
                        var text_remaining = remark_max - text_length;

                        $('#chars_left_nipccdremarks').html(text_remaining + ' remaining');
                    });
					
					

                    //show hide other details by qualification select box
                    $("#add_employee").on('change', '#qualification', function () {
                        var selectedValue = $(this).val();
                        if (selectedValue == "Other") {
                            $('#add_employee #other_detail_quali').show();
                        } else {
                            $('#add_employee #other_detail_quali').hide();
                        }
                    });
                    //show hide other land details
                    $("#add-land").on('change', '#p_type', function () {
                        var selectedValue = $(this).val();
                        if (selectedValue == "other") {
                            $('#add-land #other_land').show();
                        } else {
                            $('#add-land #other_land').hide();
                            
                            if($('#other_land').length > 0){
                                $('#other_land_det').val('');
                            }
                        }
                    });
                    // for calculate amount in Cost Per Benificiaries
                    $('#benificiaries_covered_men').keyup(multiply);
                    $('#benificiaries_covered_women').keyup(multiply);
                });

                function updatebenificiariescount()
                {
                    var benificiaries_covered_total = 0;
                    
                    var benificiaries_covered_men = $('#benificiaries_covered_men').val();
                    benificiaries_covered_men = $.trim(benificiaries_covered_men);
                    if(benificiaries_covered_men == ''){
                        benificiaries_covered_men = 0;
                    }
                    
                    var benificiaries_covered_women = $('#benificiaries_covered_women').val();
                    benificiaries_covered_women = $.trim(benificiaries_covered_women);
                    if(benificiaries_covered_women == ''){
                        benificiaries_covered_women = 0;
                    }
                    
                    benificiaries_covered_total = parseInt(benificiaries_covered_men) + parseInt(benificiaries_covered_women);
                    $("#benificiaries_covered_total").val(benificiaries_covered_total);
                }

                function multiply(e)
                {
                    var benificiaries_covered_men = $('#benificiaries_covered_men').val();
                    benificiaries_covered_men = $.trim(benificiaries_covered_men);
                    if(benificiaries_covered_men == ''){
                        benificiaries_covered_men = 0;
                    }
                    
                    var benificiaries_covered_women = $('#benificiaries_covered_women').val();
                    benificiaries_covered_women = $.trim(benificiaries_covered_women);
                    if(benificiaries_covered_women == ''){
                        benificiaries_covered_women = 0;
                    }
                    
                    var total = parseInt(benificiaries_covered_men) + parseInt(benificiaries_covered_women);
                    $('#benificiaries_covered_total').val(total);
                }

                //annextureIpartA11
                function add_bank_detail(id) {

                    if (id > 0)
                    {
                        $('#show_bank_detail').modal('show'); // show bootstrap modal when complete loaded
                        var bank = bankDetails[id];
                        $("#bank_name").val(bank.bank_name).prop("disabled", "true");
                        $("#acc_name").val(bank.holder_name);
                        $("#acc_number").val(bank.account_no);
                        $("#i_code").val(bank.ifsc);
                        $("#m_code").val(bank.micrcode);
                        $("#bank_id").val(bank.bank_id);
                        $("#add_bank").val("Update Bank Details");
                    } else
                    {
                        $('#show_bank_detail').modal('show'); // show bootstrap modal when complete loaded
                        $("#bank_name").val("").removeAttr("disabled"); //
                        $("#acc_name").val("");
                        $("#acc_number").val("");
                        $("#i_code").val("");
                        $("#m_code").val("");
                        $("#bank_id").val(0);
                        $("#add_bank").val("Add Bank Details");
                    }
                }

                function update_details(id) {

                    if (id > 0)
                    {
                        $('#show_update_details').modal('show'); // show bootstrap modal when complete loaded
                        var member = executiveMembers[id];
                        $("#name").val(member.name);
                        $("#address").val(member.address);
                        $("#landline").val(member.landline);
                        $("#fax").val(member.fax);
                        $("#mobile").val(member.mobile_no);
                        $("#email").val(member.email_id);
                        $("#aadhar").val(member.aadhar_no);
                        $("#pan").val(member.pan_no);
                        $("#member_id").val(member.exe_member_id);
                        $("#update_data").text("Update");
                    } else
                    {
                        $('#show_update_details').modal('show');
                        $("#name").val("");
                        $("#address").val("");
                        $("#landline").val("");
                        $("#fax").val("");
                        $("#mobile").val("");
                        $("#email").val("");
                        $("#aadhar").val("");
                        $("#pan").val("");
                        $("#member_id").val(0);
                        $("#update_data").text("Add");
                    }
                }
                //annextureIpartA12
                function add_employee(id) {
                    
                    // show bootstrap modal when complete loaded
                    if (id > 0)
                    {
                        $('#add_employee').modal('show'); // show bootstrap modal when complete loaded
                        var employee = trainerDetails[id];
                        $("#person_name").val(employee.name);
                        $("#qualification").val(employee.qualification);
                        $("#datepicker").val(employee.date_of_birth);
                        $("#experience").val(employee.experience);
                        $("#salary").val(employee.salary);
                        $("#pan_no").val(employee.pan_no);
                        $("#aadhar_no").val(employee.aadhar_no);
                        $("#member_id").val(id);
                        $("#save_trainer").val("Update Employees");
                    } else
                    {
                        $('#add_employee').modal('show');
                        $("#person_name").val("");
                        $("#qualification").val("");
                        $("#datepicker").val("");
                        $("#experience").val("");
                        $("#salary").val("");
                        $("#pan_no").val("");
                        $("#aadhar_no").val("");
                        $("#member_id").val(0);
                        $("#save_trainer").val("Add Employees");
                    }
                }
                function add_land(id) {

                    if (id > 0)
                    {
                        $('#add_land').modal('show'); // show bootstrap modal when complete loaded
                        var land = landAndBuildingDetails[id];
                        $("#state_list").val(land.loc_state);
                        $("#district").val(land.loc_district);
                        getDistricts_landUpdate(land.loc_state, land.loc_district);
                        console.log(land.loc_state);
                        console.log(land.loc_district);
                        console.log(land);
                        console.log(land.type);
                        
                        if(land.type == 'other'){
                            $('#other_land').show();
                        }
                        
                        $("#p_type").val(land.type);
                        $("#other_land_det").val(land.other_type);
                        $("#address").val(land.loc_address);
                        $("#pincode").val(land.loc_pincode);
                        $("#location_id").val(id);
                        $("#add_land_building").val("Update Land Info");
                        console.log(land);

                    } else
                    {
                        $('#add_land').modal('show');
                        $("#p_type").val("");
                        $("#other_land_det").val("");
                        $("#address").val("");
                        $("#state_list").val("");
                        $("#district").val("");
                        $("#pincode").val("");
                        $("#location_id").val(0);
                        $("#add_land_building").val("Add Land Info");
                    }
                }
                function add_equipment(id) {

                    if (id > 0)
                    {
                        $('#add_equipment').modal('show');
                        var equip = equipmentDetails[id];
                        $("#equipment_name").val(equip.name);
                        $("#quantity").val(equip.quantity);
                        $("#equipment_id").val(id);
                        $("#add_equipments").val("Update Equipment");
                    } else
                    {
                        $('#add_equipment').modal('show');
                        $("#equipment_name").val("");
                        $("#quantity").val("");
                        $("#equipment_id").val(0);
                        $("#add_equipments").val("Add Equipment");
                    }
                }
                function add_development(id) {
                    // show bootstrap modal when complete loaded
                    if (id > 0)
                    {
                        $('#add_development').modal('show'); // show bootstrap modal when complete loaded
                        var beneficiary = beneficiaryDetails[id];
                        $("#project_covered").val(beneficiary.project_name);
                        $("#benificiaries_covered_men").val(beneficiary.beni_men);
                        $("#benificiaries_covered_women").val(beneficiary.beni_women);
                        $("#benificiaries_covered_total").val(beneficiary.beni_total);
                        $("#project_cost").val(beneficiary.project_cost);
                        $("#s_funding").val(beneficiary.source_funding);
                        $("#projects_id").val(id);
                        $("#add_organizational_capacity").val("Update Details");
                    } else
                    {
                        $('#add_development').modal('show');
                        $("#project_covered").val("");
                        $("#benificiaries_covered_men").val("");
                        $("#benificiaries_covered_women").val("");
                        $("#benificiaries_covered_total").val("");
                        $("#project_cost").val("");
                        $("#s_funding").val("");
                        $("#projects_id").val(0);
                        $("#add_organizational_capacity").val("Add Details");
                    }
                }
                function add_financial(id) {

					
                    if (id > 0)
                    {
                        $('#add_financial').modal('show'); // show bootstrap modal when complete loaded
                        var financial = financialDetails[id];
                        
                        var html_str = '';
                        html_str += '<option value="">Select</option>';
                        $.each($.parseJSON(lasThreeFinancialYear), function(index,item){
                           html_str += '<option value="'+item+'">'+item+'</option>';
                        });
                        
                        $("#financial_year").html(html_str).prop('readonly',true).val(financial.year);
                        $("#assets").val(financial.assets);
                        $("#liabilities").val(financial.liabilites);
                        $("#income").val(financial.income);
                        $("#expenditure").val(financial.expanses);
                        $("#receipt").val(financial.reciept);
                        $("#payment").val(financial.payments);
                        $("#surplus_defict").val(financial.surplus_deficts);
                        $("#fid").val(id);
                        $("#add_inancial").val("Update Financial Status");
                    } else
                    {
                        $('#add_financial').modal('show');
                        
                        var financialYear = '';
                        if(selectedFinancialYear != ''){
                            financialYear = $.parseJSON(selectedFinancialYear);
                            financialYear = financialYear[0].year;
                        }
                        if(financialYear != ''){
                            var html_str = '';
                            html_str += '<option value="">Select</option>';
                            $.each($.parseJSON(lasThreeFinancialYear), function(index,item){
                                if(financialYear != item){
                                    html_str += '<option value="'+item+'">'+item+'</option>';
                                }
                            });
                            $("#financial_year").html(html_str).prop('readonly',true).val("");
                        }
                        else
                        {
                            $("#financial_year").val("");
                        }
                        $("#assets").val("");
                        $("#liabilities").val("");
                        $("#income").val("");
                        $("#expenditure").val("");
                        $("#receipt").val("");
                        $("#payment").val("");
                        $("#surplus_defict").val("");
                        $("#fid").val(0);
                        $("#add_inancial").val("Add Financial Status");
                    }
                }
                function add_grants(id) {
                    if (id > 0)
                    {
                        $('#add_grants').modal('show'); // show bootstrap modal when complete loaded
                        var grant = grantDetails[id];
                        $("#source_funding").val(grant.s_funding);
                        $("#date").val(grant.date);
                        $("#period").val(grant.period);
                        $("#amount").val(grant.amount);
                        $("#project_details").val(grant.p_details);
                        $("#weather_completed").val(grant.wether_completed);
                        $("#grant_id").val(id);
                        $("#add_grant").val("Update Grant Details");
                    } else
                    {
                        $('#add_grants').modal('show');
                        $("#source_funding").val("");
                        $("#date").val("");
                        $("#period").val("");
                        $("#amount").val("");
                        $("#project_details").val("");
                        $("#weather_completed").val("");
                        $("#grant_id").val(0);
                        $("#add_grant").val("Add Grant Details");
                    }
                }
                function add_trainers(id) {
                    if (id > 0)
                    {
                        var base_url = $('#base_url').val();

                        $.ajax({
                            type: "POST",
                            url: base_url + 'ngo/getTrainersInfo',
                            data: {'id': id, 'csrf_test_name':csrf_token},
                            success: function (data) {
                                console.log(data);
                                var trnr = $.parseJSON(data);
                                $('#add_trainer').modal('show');  // show bootstrap modal when complete loaded
                                //var trnr = trainersDetails[id];
                                $("#person_name").val(trnr.name);
                                $("#qualification").val(trnr.qualification);
                                $("#datepicker").val(trnr.date_of_birth);
                                $("#experience").val(trnr.experience);
                                $("#salary").val(trnr.salary);
                                $("#pan_no").val(trnr.pan_no);
                                $("#member_id").val(id);
                                $("#aadhar_no").val(trnr.aadhar_no);
                                $("#save_trainer").val("Update Trainer");
                            }
                        });
                    } else
                    {
                        $('#add_trainer').modal('show');
                        $("#person_name").val("");
                        $("#qualification").val("");
                        $("#datepicker").val("");
                        $("#experience").val("");
                        $("#salary").val("");
                        $("#pan_no").val("");
                        $("#member_id").val(0);
                        $("#aadhar_no").val("");
                        $("#save_trainer").val("Add Trainer");
                    }
                }
                function getDistricts(id)
                {
                    var state = $("#" + id).val();

                    $.ajax({
                        type: "get",
                        url: baseURL + 'ngo/getDistrictsByStateId',
                        data: 'stateId='+state+'&'+token_name+'='+csrf_token,
                        dataType: 'json',
                        success: function (jsondata) {
                            if (jsondata.status == true)
                            {
                                var districts = "";
                                districts += "<option value=''>Select District</option>";
                                for (var i = 0; i < jsondata.data.length; i++)
                                {
                                    districts += "<option value='" + jsondata.data[i].district_id + "'>" + jsondata.data[i].district_name + "</option>";
                                }
                                $("#district").html(districts);
                            }
                        },
                        error: function (jqXHR, text, error) {

                        }
                    });
                }

                function getDistricts_landUpdate(state, district_id)
                {
                    //alert(state);
                    $.ajax({
                        type: "get",
                        url: baseURL + 'ngo/getDistrictsByStateId',
                        data:'stateId='+state+'&'+token_name+'='+csrf_token,
                        dataType: 'json',
                        success: function (jsondata) {
                            if (jsondata.status == true)
                            {
                                var districts = "";
                                districts += "<option value=''>Select District</option>";
                                for (var i = 0; i < jsondata.data.length; i++)
                                {
                                    if (parseInt(district_id) == parseInt(jsondata.data[i].district_id))
                                    {
                                        districts += "<option selected value='" + jsondata.data[i].district_id + "'>" + jsondata.data[i].district_name + "</option>";
                                    } else {

                                        districts += "<option value='" + jsondata.data[i].district_id + "'>" + jsondata.data[i].district_name + "</option>";
                                    }
                                }
                                $("#district").html(districts);
                            }
                        },
                        error: function (jqXHR, text, error) {

                        }
                    });
                }
                //ajax use all form
                //executive members list
                $(function () {
                    $("#update_details_data").submit(function () {
                        var formID = $(this).attr('id');
                        var formDetails = $('#' + formID);
                        var base_url = $('#base_url').val();
                        $.ajax({
                            type: "POST",
                            url: base_url + 'ngo/insertMembersExe',
                            data: formDetails.serialize(),
                            dataType: 'json',
                            success: function (data) {
								
								if(data.status != true){
									
		             	      if (data.errors) {
				                 $('#msg_members').html(data.errors);
			                         }
		                       }	
                                if (data.status == true)
                                {
									 $('#msg_members').show();	
                                    swal({
                                        title: "Success",
                                        text: data.message,
                                        type: "success",
                                        confirmButtonText: "OK",
                                    },
                                            function () {
                                                location.href = baseURL + "ngo/annextureIpartA11?a=1&aid=" + data.application_no;
                                            });
                                }
                            },
                            error: function (jqXHR, text, error) {

                            }
                        });
                        return false;
                    });
                });


                function deleteEquipment(id)
                {
                    if (id > 0)
                    {
                        swal({
                            title: "Warning",
                            text: "Are You Sure You Want to Delete.",
                            type: "warning",
                            confirmButtonText: "Delete",
                            showCancelButton: true,
                        },
                                function () {

                                    $.ajax({
                                        type: "get",
                                        url: baseURL + 'ngo/deleteEquipment',
                                         data: 'id='+id+'&'+token_name+'='+csrf_token,
                                        dataType: 'json',
                                        success: function (data) {
                                            if (data.status == true)
                                            {
                                                swal({
                                                    title: "Success",
                                                    text: data.message,
                                                    type: "success",
                                                    confirmButtonText: "OK",
                                                },
                                                        function () {
                                                            location.href = location.href;
                                                        });
                                            }
                                        },
                                        error: function (jqXHR, text, error) {

                                        }
                                    });


                                });




                    }
                }


                function deleteEmployee_step(id)
                {
                    //alert(id);
                    if (id > 0)
                    {
                        swal({
                            title: "Warning",
                            text: "Are You Sure You Want to Delete.",
                            type: "warning",
                            confirmButtonText: "Delete",
                            showCancelButton: true,
                        },
                                function () {

                                    $.ajax({
                                        type: "get",
                                        url: baseURL + 'ngo/deleteEmp_step',
                                         data: 'id='+id+'&'+token_name+'='+csrf_token,
                                        dataType: 'json',
                                        success: function (data) {
                                            if (data.status == true)
                                            {
                                                swal({
                                                    title: "Success",
                                                    text: data.message,
                                                    type: "success",
                                                    confirmButtonText: "OK",
                                                },
                                                        function () {
                                                            $('#trainer-detai > tbody > tr#tr_' + id).remove();
                                                        });
                                            }
                                        },
                                        error: function (jqXHR, text, error) {

                                        }
                                    });


                                });

                    }
                }

                function deleteBankDetails(id)
                {
                    if (id > 0)
                    {
                        swal({
                            title: "Warning",
                            text: "Are You Sure You Want to Delete.",
                            type: "warning",
                            confirmButtonText: "Delete",
                            showCancelButton: true,
                        },
                                function () {

                                    $.ajax({
                                        type: "get",
                                        url: baseURL + 'ngo/deleteBankDetails',
                                       data:'id='+id+'&'+token_name+'='+csrf_token,
                                        dataType: 'json',
                                        success: function (data) {
                                            if (data.status == true)
                                            {
                                                swal({
                                                    title: "Success",
                                                    text: data.message,
                                                    type: "success",
                                                    confirmButtonText: "OK",
                                                },
                                                        function () {
                                                            location.href = location.href;
                                                        });
                                            }
                                        },
                                        error: function (jqXHR, text, error) {

                                        }
                                    });


                                });



                    }
                }


                function deleteLandBuilding(id)
                {
                    if (id > 0)
                    {
                        swal({
                            title: "Warning",
                            text: "Are You Sure You Want to Delete.",
                            type: "warning",
                            confirmButtonText: "Delete",
                            showCancelButton: true,
                        },
                                function () {

                                    $.ajax({
                                        type: "get",
                                        url: baseURL + 'ngo/deleteLandBuilding',
                                        data: 'id='+id+'&'+token_name+'='+csrf_token,
                                        dataType: 'json',
                                        success: function (data) {
                                            if (data.status == true)
                                            {
                                                swal({
                                                    title: "Success",
                                                    text: data.message,
                                                    type: "success",
                                                    confirmButtonText: "OK",
                                                },
                                                        function () {
                                                            location.href = location.href;
                                                        });
                                            }
                                        },
                                        error: function (jqXHR, text, error) {

                                        }
                                    });


                                });




                    }
                }
                function deleteDevelopment(id)
                {
                    if (id > 0)
                    {
                        swal({
                            title: "Warning",
                            text: "Are You Sure You Want to Delete.",
                            type: "warning",
                            confirmButtonText: "Delete",
                            showCancelButton: true,
                        },
                                function () {

                                    $.ajax({
                                        type: "get",
                                        url: baseURL + 'ngo/deleteDevelopment',
                                        data: 'id='+id+'&'+token_name+'='+csrf_token,
                                        dataType: 'json',
                                        success: function (data) {
                                            if (data.status == true)
                                            {
                                                swal({
                                                    title: "Success",
                                                    text: data.message,
                                                    type: "success",
                                                    confirmButtonText: "OK",
                                                },
                                                        function () {
                                                            location.href = location.href+'&dialog=true';
                                                        });
                                            }
                                        },
										 sending:function(file, xhr, formData){
            formData.append(token_name, csrf_token);  
           },
                                        error: function (jqXHR, text, error) {

                                        }
                                    });


                                });

                    }
                }


                function deleteGrants(id)
                {
                    if (id > 0)
                    {
                        swal({
                            title: "Warning",
                            text: "Are You Sure You Want to Delete.",
                            type: "warning",
                            confirmButtonText: "Delete",
                            showCancelButton: true,
                        },
                                function () {

                                    $.ajax({
                                        type: "get",
                                        url: baseURL + 'ngo/deleteGrants',
                                        data: 'id='+id+'&'+token_name+'='+csrf_token,
                                        dataType: 'json',
                                        success: function (data) {
                                            if (data.status == true)
                                            {
                                                swal({
                                                    title: "Success",
                                                    text: data.message,
                                                    type: "success",
                                                    confirmButtonText: "OK",
                                                },
                                                        function () {
                                                            location.href = location.href;
                                                        });
                                            }
                                        },
				sending:function(file, xhr, formData){
            formData.append(token_name, csrf_token);  
           },
                                        error: function (jqXHR, text, error) {

                                        }
                                    });


                                });



                    }
                }
                // Delete Members

                function deleteMembers(id)
                {
                    if (id > 0)
                    {
                        swal({
                            title: "Warning",
                            text: "Are You Sure You Want to Delete.",
                            type: "warning",
                            confirmButtonText: "Delete",
                            showCancelButton: true,
                        },
                                function () {

                                    $.ajax({
                                        type: "get",
                                        url: baseURL + 'ngo/deleteExecutiveMembrs',
                                         data:'id='+id+'&'+token_name+'='+csrf_token,
                                        dataType: 'json',
                                        success: function (data) {
                                            if (data.status == true)
                                            {
                                                swal({
                                                    title: "Success",
                                                    text: data.message,
                                                    type: "success",
                                                    confirmButtonText: "OK",
                                                },
                                                        function () {
                                                            location.href = location.href;
                                                        });
                                            }
                                        },
										 sending:function(file, xhr, formData){
										formData.append(token_name, csrf_token);  
									   },
                                        error: function (jqXHR, text, error) {

                                        }
                                    });


                                });



                    }
                }
                //add bank name
                $(function () {
                    $("#add-banks-sg").submit(function () {
                        var formID = $(this).attr('id');
                        var formDetails = $('#' + formID);
                        var base_url = $('#base_url').val();
                        
                        if($('#bank_name').is(':disabled')){
                            //Remove bank
                            $('.hdnbank').remove();
                            
                            var bank_name = $('#bank_name').val();
                            bank_name = $.trim(bank_name);
                            $(this).append("<input type='hidden' name='bank_name' id='bank_name' class='hdnbank' value='"+bank_name+"'/>");
                        }
                        
                        $.ajax({
                            type: "POST",
                            url: baseURL + 'ngo/insertBankName',
                            data: formDetails.serialize(),
                            dataType: "json",
                            success: function (data) {
                                if (data.status != true) {
                                    if (data.errors) {
                                        $('#msg_bankdetails, #msg').html(data.errors);
                                    }
                                }
                                if (data.status == true)
                                {
                                    $('#msg_bankdetails').hide();
                                    swal({
                                        title: "Success",
                                        text: data.message,
                                        type: "success",
                                        confirmButtonText: "OK",
                                    },
                                    function(){
                                        location.href = location.href+'&dialog=true';
                                    });
                                }
                            },
                            error: function (jqXHR, text, error) {
                                // Displaying if there are any errors
                                $('#show_bank_detail .modal-title').html(error);
                            }
                        });
                        return false;
                    });
                });

                //add emp and trainers
                $(function () {

                    $("#frm_details_ngo").parent("div").addClass("pdfdiv");
                    $("#frm_ngo_export").submit(function () {
                        var ht = $(".mytablehtml").html();
                        $('<input />').attr('type', 'hidden')
                                .attr('name', "myHTML")
                                .attr('value', ht)
                                .appendTo('#frm_ngo_export');
                        return true;
                    });

                    $("#frm_details_ngo").submit(function () {
                        
                        //Html String for Exporting Pdf
                        var ht = $(".detailpagepdf").prop("outerHTML");
                        
                        if($('.exportPdf').length > 0 || $('.p_tag_remarks').length > 0)
                        {
                            ht = getRemoveUnwantedTags('form, .exportPdf, input', ht);
                            ht = $("<div/>").append($('.p_tag_remarks', ht).replaceWith('<p>Remarks :</p>').end()).html();
                            
                            if($('.viewRemark').length > 0){
                                ht = $("<div/>").append($('.viewRemark', ht).replaceWith('<br/>'+$('.viewRemark').val()).end()).html();
                            }else{
                                ht = showRemarkTags('.exportRemark', ht);
                            }
                        }
                        
                        $('<input />').attr('type', 'hidden')
                                .attr('name', "myHTML")
                                .attr('value', ht)
                                .appendTo('#frm_details_ngo');
                        return true;
                    });

                    $("#add-employee").submit(function () {
                        var formID = $(this).attr('id');
                        var formDetails = $('#' + formID);
                        var base_url = $('#base_url').val();
                        $.ajax({
                            type: "POST",
                            url: baseURL + 'ngo/insertEmp',
                            data: formDetails.serialize(),
                            dataType: "json",
                            success: function (data) {
                                if (data.status == true)
                                {
                                    swal({
                                        title: "Success",
                                        text: data.message,
                                        type: "success",
                                        confirmButtonText: "OK",
                                    },
                                            function () {
                                                location.href = location.href+'&dialog=true';
                                            });
                                }
                               if(data.status == false){
									
		             	      if (data.errors) {
				                 $('#add-employee-msg').html(data.errors);
			                         }
		                       }	

                            },
                            error: function (jqXHR, text, error) {
                                // Displaying if there are any errors
                                $('#add_employee .modal-title').html(error);
                            }
                        });
                        return false;
                    });
                });
                //add land building
                $(function () {
                    $("#add-land").submit(function () {
                        var formID = $(this).attr('id');
                        var formDetails = $('#' + formID);
                        var base_url = $('#base_url').val();
                        $.ajax({
                            type: "POST",
                            url: base_url + 'ngo/insertLand',
                            data: formDetails.serialize(),
                            dataType: "json",
                            success: function (data) {
								if(data.status == false){
									
		             	      if (data.errors) {
				                 $('#add-land-msg').html(data.errors);
			                         }
		                       }	
								
                                if (data.status == true)
                                {
                                    swal({
                                        title: "Success",
                                        text: data.message,
                                        type: "success",
                                        confirmButtonText: "OK",
                                    },
                                            function () {
                                                //location.href = location.href;
                                                 location.href = location.href+'&dialog=true';	
                                            });
                                }
                              
                            },
                            error: function (jqXHR, text, error) {
                                // Displaying if there are any errors
                                $('#add_land .modal-title').html(error);
                            }
                        });
                        return false;
                    });
                });
                //add equipment
                $(function () {
                    $("#add-equipment").submit(function () {
                        var formID = $(this).attr('id');
                        var formDetails = $('#' + formID);
                        var base_url = $('#base_url').val();
                        $.ajax({
                            type: "POST",
                            url: base_url + 'ngo/insertEquipment',
                            data: formDetails.serialize(),
                            dataType: "json",
                            success: function (data) {
                                if (data.status == true)
                                {
                                    swal({
                                        title: "Success",
                                        text: data.message,
                                        type: "success",
                                        confirmButtonText: "OK",
                                    },
                                            function () {

                                                window.location = window.location.href+'&dialog=true';

                                            });
                                }
                                if(data.status == false){
									
		             	      if (data.errors) {
				                 $('#add-equipment-msg').html(data.errors);
			                         }
		                       }
                            },
                            error: function (jqXHR, text, error) {
                                // Displaying if there are any errors
                                $('#add_equipment .modal-title').html(error);
                            }
                        });
                        return false;
                    });
                });

                //add development
                $(function () {
                    $("#add-development").submit(function () {
                        var formID = $(this).attr('id');
                        var formDetails = $('#' + formID);
                        var base_url = $('#base_url').val();
                        $.ajax({
                            type: "POST",
                            url: base_url + 'ngo/insertDevelopment',
                            data: formDetails.serialize(),
                            dataType: "json",
                            success: function (data) {
                                if (data.status == true)
                                {
                                    swal({
                                        title: "Success",
                                        text: data.message,
                                        type: "success",
                                        confirmButtonText: "OK",
                                    },
                                            function () {
                                                location.href = location.href+'&dialog=true';
                                            });
                                }
                                if(data.status == false){
									
		             	      if (data.errors) {
				                 $('#add-development-msg').html(data.errors);
			                         }
		                       }

                            },
                            error: function (jqXHR, text, error) {
                                // Displaying if there are any errors
                                $('#add_development .modal-title').html(error);
                            }
                        });
                        return false;
                    });
                });

                //add financial
                $(function () {
                    $("#add-financial").submit(function () {
                        var formID = $(this).attr('id');
                        var formDetails = $('#' + formID);
                        var base_url = $('#base_url').val();
                        $.ajax({
                            type: "POST",
                            url: base_url + 'ngo/insertFinancial',
                            data: formDetails.serialize(),
                            dataType: "json",
                            success: function (data) {
								
								 if (data.status != true)
                                {
									
                                    if (data.errors) {
										$('#add-financial-msg').html(data.errors);
			                         }
                                }
                                if (data.status == true)
                                {
                                    swal({
                                        title: "Success",
                                        text: data.message,
                                        type: "success",
                                        confirmButtonText: "OK",
                                    },
                                            function () {
                                                  location.href = location.href+'&dialog=true';
                                            });
                                }
                               
								
                            },
                            error: function (jqXHR, text, error) {
                                // Displaying if there are any errors
                                $('#add_financial .modal-title').html(error);
                            }
                        });
                        return false;
                    });
                });

                //add grants
                $(function () {
                    $("#add-grants").submit(function () {
                        var formID = $(this).attr('id');
                        var formDetails = $('#' + formID);
                        var base_url = $('#base_url').val();
                        $.ajax({
                            type: "POST",
                            url: base_url + 'ngo/insertGrants',
                            data: formDetails.serialize(),
                            dataType: "json",
                            success: function (data) {
                                if (data.status == true)
                                {
                                    swal({
                                        title: "Success",
                                        text: data.message,
                                        type: "success",
                                        confirmButtonText: "OK",
                                    },
                                            function () {
                                                  location.href = location.href+'&dialog=true';
                                            });
                                }
                                if (data.status == false)
                                {
                                     if (data.errors) {
				                 $('#add-grants-msg').html(data.errors);
			                         }
                                }
                            },
                            error: function (jqXHR, text, error) {
                                // Displaying if there are any errors
                                $('#add_grants .modal-title').html(error);
                            }
                        });
                        return false;
                    });
                });
                //add trainer
                $(function () {
                    $("#add-trainer").submit(function () {

                        var formID = $(this).attr('id');
                        var formDetails = $('#' + formID);
                        //console.log(formDetails);
                        var base_url = $('#base_url').val();

                        $.ajax({
                            type: "POST",
                            url: baseURL + 'ngo/insertTrainers',
                            data: formDetails.serialize(),
                            dataType: "json",
                            success: function (data) {
                                console.log(data);
                                if (data.status == true)
                                {
									 $('#add-trainer-msg').hide();
                                    if ($("#member_id").val() <= 0)
                                    {
										
                                        var row = "<tr id='tr_" + data.member_id + "'>";
                                        row += "<td>" + $("#person_name").val() + "</td>";
                                        row += "<td>" + $("#qualification option:selected").text() + "</td>";
                                        row += "<td>" + $("#datepicker").val() + "</td>";
                                        row += "<td>" + $("#experience option:selected").text() + "</td>";
                                        row += "<td>" + $("#salary").val() + "</td>";
                                        row += "<td>" + $("#pan_no").val() + "</td>";
                                        row += "<td>" + $("#aadhar_no").val() + "</td>";

                                        row += '<td><a href="javascript:void(0);" class="icon_link" id="' + data.member_id + '" onclick="add_trainers(this.id)"><i class="fa fa-pencil" aria-hidden="true"></i></a><span class="space">&nbsp;&nbsp;&nbsp;</span><a href="javascript:void(0);" id="' + data.member_id + '" onclick="deleteEmployee_step(this.id);" class="icon_link"><i class="fa fa-trash" aria-hidden="true"></i></a></td>';
                                        row += "</tr>";
                                        if ($('#trainer-detai tbody tr td').size() > 1)
                                        {
                                            $('#trainer-detai tbody').append(row);

                                        } else
                                        {
                                            $('#trainer-detai tbody tr').remove();
                                            $('#trainer-detai tbody').append(row);

                                        }
                                    } else
                                    {

                                        var id = $("#member_id").val();
										
                                        $('#trainer-detai > tbody > tr#tr_' + id + ' > td:eq(0)').text($("#person_name").val());
                                        $('#trainer-detai > tbody > tr#tr_' + id + ' > td:eq(1)').text($("#qualification option:selected").text());
                                        $('#trainer-detai > tbody > tr#tr_' + id + ' > td:eq(2)').text($("#datepicker").val());
                                        $('#trainer-detai > tbody > tr#tr_' + id + ' > td:eq(3)').text($("#experience option:selected").text());
                                        $('#trainer-detai > tbody > tr#tr_' + id + ' > td:eq(4)').text($("#salary").val());
                                        $('#trainer-detai > tbody > tr#tr_' + id + ' > td:eq(5)').text($("#pan_no").val());
                                        $('#trainer-detai > tbody > tr#tr_' + id + ' > td:eq(6)').text($("#aadhar_no").val());
                                    }
                                    swal({
                                        title: "Success",
                                        text: data.message,
                                        type: "success",
                                        confirmButtonText: "OK",
                                    },
                                            function () {
                                                //$('#add_trainer').hide();
                                                $("#add_trainer").modal('hide');
                                                //$('.modal-backdrop').hide();
                                                //$('body').removeClass("modal-open");
                                            });
                                }
                                if (data.status == false)
                                {
                                    if (data.errors) {
                                       $('#add-trainer-msg').html(data.errors);
                                      }
                                }

                            },
							sending:function(file, xhr, formData){
            formData.append(token_name, csrf_token);  
           },
                            error: function (jqXHR, text, error) {
                                // Displaying if there are any errors
                                console.log(error);
                                console.log(jqXHR);
                                console.log(text);
                                //$('#add-location .modal-title').html(error);           
                            }
                        });
                        return false;
                    });
                });

                function updatefinancialyear()
                {
                    var payment = $('#payment').val();
                    var receipt = $('#receipt').val();
                    var surplus_defict = receipt - payment;
                    $('#surplus_defict').val(surplus_defict);

                }

                $(function () {
                    $("#trades").on('change', function () {
                        var selectedsector = $("#sector").val();
                        var trade = $("#trades").val();
                        var base_url = $('#base_url').val();
                        $.cookie("type", selectedsector);
                        $.ajax({
                            type: "get",
                            url: base_url + 'ngo/selectTrade',
                            data: {"selectedsector": selectedsector, "trade": trade},
                            dataType: "json",
                            success: function (jsonData) {

                                var trades = "";
                                if (jsonData.status == true)
                                {
                                    for (var i = 0; i < jsonData.data.length; i++)
                                    {
                                        trades += "<option value='" + jsonData.data[i].category_id + "'>" + jsonData.data[i].category_name + "</option>";
                                    }
                                }
                                $("#course").empty().append(trades);
                            }
                        });
                        return false;
                    });
                });

                function getDistrictregister(id)
                {
                    $.ajax({
                        type: "get",
                        url: baseURL + 'users/getDistrictsByStateIds',
                        data:'stateId='+id+'&'+token_name+'='+csrf_token,
                        dataType: 'json',
                        success: function (jsondata) {
                            if (jsondata.status == true)
                            {
                                var districts = "";
                                districts += "<option value=''>Select District</option>";
                                for (var i = 0; i < jsondata.data.length; i++)
                                {
                                    districts += "<option value='" + jsondata.data[i].district_id + "'>" + jsondata.data[i].district_name + "</option>";
                                }
                                $("#district_register").html(districts);
                            }
                        },
                        error: function (jqXHR, text, error) {

                        }
                    });
                }
		function getUserRole(id)
                {
                    /****remove checked property from scheme*****/
                    $('.schemechecked').removeAttr('checked');
                    /*****REMOVE VALUE PROPERTY FROM EMAIL ID********/
                     $("#stateUesremail").val('');
                         $("#stateUesremail").next().html('');
                    var flagid = id;
                    if (flagid != '' && flagid!='15') {
                        $.ajax({
                            type: "get",
                            url: baseURL + 'users/getUserByFlagIds',
                            data: 'flagId=' + flagid + '&' + token_name + '=' + csrf_token,
                            url: baseURL + 'users/getUserByFlagIds',
                            data: 'flagId=' + flagid + '&' + token_name + '=' + csrf_token,
                            dataType: 'json',
                            success: function (jsondata) {
                                if (jsondata.status == true)
                                {
                                    var userrole = "";
                                    userrole += "<option value=''>Select User Type</option>";
                                    for (var i = 0; i < jsondata.data.length; i++)
                                    {
                                        userrole += "<option value='" + jsondata.data[i].id + "'>" + jsondata.data[i].designation + "</option>";
                                    }
                                    $("#userrole_list").html(userrole);
                                     $("#utypegroup").show();
                                     if(flagid!='2'){
                                     $('.schemechecked').prop('type','radio');
                                     }else{
                                        
                                         $('.schemechecked').prop('type','checkbox')
                                     }
                                     if(flagid=='3'){
                                       $('#scheme_2').hide(); 
                                     }else {  $('#scheme_2').show(); }
                                }
                            }
                        });
                    }else{
                        $("#utypegroup").hide();
                    }
                    if(flagid !='' && flagid=='2'){
                        $("#goistatetab").hide();
                    }else{
                        $("#goistatetab").show();
                    }
                }
                
                function deleteEmployee(id)
                {
                    if (id > 0)
                    {
                        swal({
                            title: "Warning",
                            text: "Are You Sure You Want to Delete.",
                            type: "warning",
                            confirmButtonText: "Delete",
                            showCancelButton: true,
                        },
                                function () {

                                    $.ajax({
                                        type: "get",
                                        url: baseURL + 'ngo/deleteEmployee',
                                        data:'id='+id+'&'+token_name+'='+csrf_token,
                                        dataType: 'json',
                                        success: function (data) {
                                            if (data.status == true)
                                            {
                                                swal({
                                                    title: "Success",
                                                    text: data.message,
                                                    type: "success",
                                                    confirmButtonText: "OK",
                                                },
                                                 
                                                        function () {
                                                            location.href = location.href+'&dialog=true';
                                                        });
                                            }
                                        },
                                         sending:function(file, xhr, formData){
                                        formData.append(token_name, csrf_token);  
                                        },
                                        error: function (jqXHR, text, error) {

                                        }
                                    });


                                });

                    }
                }
                
                
                
                //Remove Unwanted Html Tags From a string
                function getRemoveUnwantedTags(theTarget, theString)
                {
                    return $("<div/>").append($(theTarget, theString).remove().end()).html();
                }
                
                //Show Remark
                function showRemarkTags(theTarget, theString)
                {
                    return $("<div/>").append($(theTarget, theString).replaceWith('<br><br><br>').end()).html();
                }
